package com.srltcp.compass;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {

    private static final String PREFS = "compass";
    private static final int REQ_LOCATION = 1;
    // Low-pass smoothing for the heading (0..1, lower = smoother).
    private static final float ALPHA = 0.12f;
    // A GPS fix older than this no longer counts as a current fix.
    private static final long FIX_TIMEOUT_MS = 10_000;

    private static final int GREEN = Color.rgb(124, 252, 0);
    private static final int AMBER = Color.rgb(255, 167, 38);
    private static final int RED = Color.rgb(239, 83, 80);

    private SensorManager sensorManager;
    private Sensor rotation, accel, magnet;
    private LocationManager locationManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private CompassView view;

    private TextView status, sats, accuracy, altitude, latitude, longitude, speed, age,
            systems, signal;

    private final float[] gravity = new float[3];
    private final float[] geomag = new float[3];
    private boolean haveGravity, haveGeomag;
    private final float[] r = new float[9];
    private final float[] remapped = new float[9];
    private final float[] orientation = new float[3];

    // Smoothed heading kept as a unit vector so 359° -> 0° doesn't jump.
    private float hx, hy;
    private boolean haveHeading;

    private boolean trueNorth;
    private boolean haveDeclination;
    private boolean declinationFromLastFix;
    private float declination;

    private long declinationAt;
    private boolean askedThisLaunch;
    private boolean listening;
    private Location gpsFix;
    private GnssStatus gnss;

    private final GnssStatus.Callback gnssCallback = new GnssStatus.Callback() {
        @Override
        public void onSatelliteStatusChanged(GnssStatus s) {
            gnss = s;
            updateGps();
        }

        @Override
        public void onStopped() {
            gnss = null;
            updateGps();
        }
    };

    // Refreshes "fix age" and notices when the fix goes stale.
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateGps();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotation = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnet = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        SharedPreferences p = prefs();
        trueNorth = p.getBoolean("trueNorth", true);
        if (p.contains("declination")) {
            // Declination changes slowly with distance, so the last fix is a fine fallback.
            declination = p.getFloat("declination", 0f);
            haveDeclination = true;
            declinationFromLastFix = true;
        }

        view = new CompassView(this);
        view.setOnHeaderTap(() -> {
            trueNorth = !trueNorth;
            prefs().edit().putBoolean("trueNorth", trueNorth).apply();
            refreshMode();
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CompassView.BG);
        root.addView(view, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(buildGpsPanel(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (magnet == null || (rotation == null && accel == null)) {
            view.setMessage("This device has no compass sensor");
        }
        refreshMode();
        updateGps();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---- GPS panel ----

    private LinearLayout buildGpsPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.rgb(28, 36, 44));
        panel.setPadding(dp(16), dp(10), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("GPS");
        title.setTextColor(Color.rgb(77, 208, 225));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(14);
        panel.addView(title);

        status = cell(panel, "Status", sats = new TextView(this), "Satellites (used / seen)");
        accuracy = cell(panel, "Accuracy", altitude = new TextView(this), "Altitude");
        latitude = cell(panel, "Latitude", longitude = new TextView(this), "Longitude");
        speed = cell(panel, "Speed", age = new TextView(this), "Last fix");
        signal = cell(panel, "Signal (avg of used)", null, null);
        systems = cell(panel, "Systems (used / seen)", null, null);
        return panel;
    }

    /** Adds a row with one or two label/value cells; returns the left value view. */
    private TextView cell(LinearLayout panel, String leftLabel, TextView right, String rightLabel) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(6), 0, 0);
        TextView left = new TextView(this);
        row.addView(labelled(leftLabel, left), new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (right != null) {
            row.addView(labelled(rightLabel, right), new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        panel.addView(row);
        return left;
    }

    private LinearLayout labelled(String label, TextView value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(Color.GRAY);
        l.setTextSize(12);
        value.setTextColor(Color.WHITE);
        value.setTextSize(16);
        value.setTypeface(Typeface.MONOSPACE);
        value.setGravity(Gravity.START);
        value.setText("—");
        box.addView(l);
        box.addView(value);
        return box;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (rotation != null) {
            sensorManager.registerListener(this, rotation, SensorManager.SENSOR_DELAY_UI);
        } else if (accel != null) {
            sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI);
        }
        // Always listen to the magnetometer: it reports when calibration is needed.
        if (magnet != null) {
            sensorManager.registerListener(this, magnet, SensorManager.SENSOR_DELAY_UI);
        }
        startLocation();
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        stopLocation();
        handler.removeCallbacks(tick);
    }

    // ---- Location / declination ----

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Approximate location is enough for declination, but not for GPS status. */
    private boolean hasAnyLocationPermission() {
        return hasLocationPermission()
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void startLocation() {
        if (!hasLocationPermission() && !askedThisLaunch) {
            // Once per launch: Android itself stops showing the prompt after repeated denials.
            askedThisLaunch = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (!hasAnyLocationPermission()) {
            return;
        }
        if (locationManager == null) {
            return;
        }
        // Start clean, e.g. after precise location is granted while already listening.
        stopLocation();
        try {
            // Any recent location (even from Wi-Fi) is good enough for declination
            // while we wait for the first GPS fix.
            Location best = null;
            for (String provider : locationManager.getProviders(true)) {
                Location l = locationManager.getLastKnownLocation(provider);
                if (l != null && (best == null || l.getTime() > best.getTime())) {
                    best = l;
                }
            }
            if (best != null) {
                setDeclinationFrom(best);
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                // No location at all yet: a quick network fix is enough for declination.
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        60_000L, 1000f, this);
                listening = true;
            }
            if (!hasLocationPermission()) {
                return;
            }
            if (locationManager.getAllProviders().contains(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f,
                        this);
            }
            locationManager.registerGnssStatusCallback(gnssCallback, handler);
            listening = true;
        } catch (SecurityException | IllegalArgumentException ignored) {
            // Permission revoked or no GPS: fall back to the saved declination.
        }
    }

    private void stopLocation() {
        if (listening && locationManager != null) {
            try {
                locationManager.removeUpdates(this);
                locationManager.unregisterGnssStatusCallback(gnssCallback);
            } catch (SecurityException ignored) {
            }
            listening = false;
        }
    }

    private void setDeclinationFrom(Location l) {
        GeomagneticField field = new GeomagneticField(
                (float) l.getLatitude(), (float) l.getLongitude(),
                (float) l.getAltitude(), System.currentTimeMillis());
        declination = field.getDeclination();
        haveDeclination = true;
        declinationFromLastFix = false;
        declinationAt = SystemClock.elapsedRealtime();
        prefs().edit().putFloat("declination", declination).apply();
        refreshMode();
    }

    @Override
    public void onLocationChanged(Location location) {
        if (!LocationManager.GPS_PROVIDER.equals(location.getProvider())) {
            // Network fixes only seed the declination; the GPS panel shows GPS fixes only.
            if (!haveDeclination || declinationFromLastFix) {
                setDeclinationFrom(location);
            }
            return;
        }
        boolean first = gpsFix == null;
        gpsFix = location;
        // Declination barely changes as you move; refreshing every few minutes is plenty.
        if (first || declinationFromLastFix
                || SystemClock.elapsedRealtime() - declinationAt > 5 * 60_000L) {
            setDeclinationFrom(location);
        }
        updateGps();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
        updateGps();
    }

    @Override
    public void onProviderDisabled(String provider) {
        updateGps();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (requestCode == REQ_LOCATION) {
            startLocation();
            refreshMode();
            updateGps();
        }
    }

    private void refreshMode() {
        String note;
        if (!trueNorth) {
            view.setMode("MAGNETIC NORTH  ·  tap for true", haveDeclination
                    ? String.format(Locale.US, "Declination here %+.1f°", declination)
                    : null, false);
            updateHeading();
            return;
        }
        if (haveDeclination) {
            note = String.format(Locale.US, "Declination %+.1f°%s", declination,
                    declinationFromLastFix ? " (last known location)" : "");
        } else if (hasAnyLocationPermission()) {
            note = "Waiting for GPS to correct to true north…";
        } else {
            note = "Allow location in Settings to get true north";
        }
        view.setMode("TRUE NORTH  ·  tap for magnetic", note, !haveDeclination);
        updateHeading();
    }

    private void updateGps() {
        if (status == null) {
            return;
        }
        boolean gpsOn = false;
        try {
            gpsOn = locationManager != null
                    && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (IllegalArgumentException ignored) {
        }
        long ageMs = gpsFix == null ? Long.MAX_VALUE
                : (SystemClock.elapsedRealtimeNanos() - gpsFix.getElapsedRealtimeNanos())
                / 1_000_000L;
        boolean fresh = ageMs < FIX_TIMEOUT_MS;

        // Status
        if (!hasAnyLocationPermission()) {
            set(status, "No permission", RED);
        } else if (!hasLocationPermission()) {
            set(status, "Precise location off", RED);
        } else if (!gpsOn) {
            set(status, "GPS off", RED);
        } else if (fresh) {
            set(status, gpsFix.hasAltitude() ? "3D fix" : "2D fix", GREEN);
        } else {
            set(status, "Searching…", AMBER);
        }

        // Satellites
        int used = 0, seen = 0;
        float cn0Sum = 0;
        int[] sysUsed = new int[8], sysSeen = new int[8];
        if (gnss != null) {
            seen = gnss.getSatelliteCount();
            for (int i = 0; i < seen; i++) {
                int c = gnss.getConstellationType(i);
                if (c < 0 || c >= sysSeen.length) c = 0;
                sysSeen[c]++;
                if (gnss.usedInFix(i)) {
                    used++;
                    sysUsed[c]++;
                    cn0Sum += gnss.getCn0DbHz(i);
                }
            }
        }
        set(sats, gnss == null ? "—" : used + " / " + seen,
                used >= 4 ? GREEN : used > 0 ? AMBER : Color.WHITE);

        if (used > 0) {
            float avg = cn0Sum / used;
            set(signal, String.format(Locale.US, "%.0f dB-Hz  (%s)", avg,
                    avg >= 35 ? "strong" : avg >= 25 ? "fair" : "weak"),
                    avg >= 35 ? GREEN : avg >= 25 ? AMBER : RED);
        } else {
            set(signal, "—", Color.WHITE);
        }

        StringBuilder sb = new StringBuilder();
        String[] names = {"Other", "GPS", "SBAS", "GLONASS", "QZSS", "BeiDou", "Galileo", "NavIC"};
        int[] order = {1, 6, 3, 5, 4, 7, 2, 0};
        for (int c : order) {
            if (sysSeen[c] > 0) {
                if (sb.length() > 0) sb.append("   ");
                sb.append(names[c]).append(' ').append(sysUsed[c]).append('/').append(sysSeen[c]);
            }
        }
        set(systems, sb.length() == 0 ? "—" : sb.toString(), Color.WHITE);
        systems.setTextSize(14);

        // Position
        if (gpsFix != null) {
            int c = fresh ? Color.WHITE : Color.GRAY;
            set(accuracy, gpsFix.hasAccuracy()
                    ? String.format(Locale.US, "±%.0f m", gpsFix.getAccuracy()) : "—",
                    !gpsFix.hasAccuracy() || !fresh ? c
                            : gpsFix.getAccuracy() <= 10 ? GREEN
                            : gpsFix.getAccuracy() <= 30 ? AMBER : RED);
            set(altitude, gpsFix.hasAltitude()
                    ? String.format(Locale.US, "%.0f m", gpsFix.getAltitude()) : "—", c);
            set(latitude, formatCoord(gpsFix.getLatitude(), 'N', 'S'), c);
            set(longitude, formatCoord(gpsFix.getLongitude(), 'E', 'W'), c);
            set(speed, gpsFix.hasSpeed()
                    ? String.format(Locale.US, "%.1f km/h", gpsFix.getSpeed() * 3.6f) : "—", c);
            set(age, formatAge(ageMs), fresh ? Color.WHITE : AMBER);
        } else {
            for (TextView t : new TextView[]{accuracy, altitude, latitude, longitude, speed}) {
                set(t, "—", Color.WHITE);
            }
            set(age, "never", Color.WHITE);
        }
    }

    private static void set(TextView t, String text, int color) {
        t.setText(text);
        t.setTextColor(color);
    }

    private static String formatCoord(double v, char pos, char neg) {
        return String.format(Locale.US, "%.5f° %c", Math.abs(v), v >= 0 ? pos : neg);
    }

    private static String formatAge(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + " s ago";
        if (s < 3600) return (s / 60) + " min ago";
        return (s / 3600) + " h ago";
    }

    // ---- Sensors ----

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_ROTATION_VECTOR:
                SensorManager.getRotationMatrixFromVector(r, e.values);
                applyRotation();
                break;
            case Sensor.TYPE_ACCELEROMETER:
                lowPass(e.values, gravity, haveGravity);
                haveGravity = true;
                computeFromRaw();
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                lowPass(e.values, geomag, haveGeomag);
                haveGeomag = true;
                if (rotation == null) {
                    computeFromRaw();
                }
                break;
        }
    }

    private static void lowPass(float[] in, float[] out, boolean primed) {
        for (int i = 0; i < 3; i++) {
            out[i] = primed ? out[i] + 0.2f * (in[i] - out[i]) : in[i];
        }
    }

    private void computeFromRaw() {
        if (haveGravity && haveGeomag
                && SensorManager.getRotationMatrix(r, null, gravity, geomag)) {
            applyRotation();
        }
    }

    private void applyRotation() {
        float[] m = r;
        // r[8] is how much the screen faces up. When the phone is held upright,
        // measure the direction the back camera points instead of the top edge.
        if (Math.abs(r[8]) < 0.5f) {
            SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z,
                    remapped);
            m = remapped;
        }
        SensorManager.getOrientation(m, orientation);
        float az = orientation[0];
        float cx = (float) Math.cos(az), cy = (float) Math.sin(az);
        if (!haveHeading) {
            hx = cx;
            hy = cy;
            haveHeading = true;
        } else {
            hx += ALPHA * (cx - hx);
            hy += ALPHA * (cy - hy);
        }
        updateHeading();
    }

    private void updateHeading() {
        if (!haveHeading) {
            return;
        }
        // The sensors measure magnetic north; add the declination to get true north.
        float heading = (float) Math.toDegrees(Math.atan2(hy, hx));
        if (trueNorth && haveDeclination) {
            heading += declination;
        }
        heading = ((heading % 360f) + 360f) % 360f;
        view.setHeading(heading);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            view.setNeedsCalibration(accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW);
        }
    }
}
