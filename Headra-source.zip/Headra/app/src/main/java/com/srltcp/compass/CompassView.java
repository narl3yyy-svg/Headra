package com.srltcp.compass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/** A compass card that rotates so north on the card points to north in the world. */
public class CompassView extends View {

    static final int BG = Color.rgb(18, 24, 30);
    private static final int NORTH = Color.rgb(229, 57, 53);
    private static final int ACCENT = Color.rgb(77, 208, 225);
    private static final int WARN = Color.rgb(255, 167, 38);
    private static final String[] POINTS =
            {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float density;

    private boolean hasHeading;
    private float heading;
    private String mode = "";
    private String note;
    private boolean approximate;
    private boolean needsCalibration;
    private String message;
    private Runnable onHeaderTap;
    private float headerBottom;

    public CompassView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        label.setTextAlign(Paint.Align.CENTER);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        big.setColor(Color.WHITE);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        big.setTextSize(48 * density);
        small.setColor(Color.LTGRAY);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(16 * density);
    }

    void setHeading(float heading) {
        this.heading = heading;
        hasHeading = true;
        invalidate();
    }

    /** approximate = heading isn't corrected to true north yet (no location). */
    void setMode(String mode, String note, boolean approximate) {
        this.mode = mode;
        this.note = note;
        this.approximate = approximate;
        invalidate();
    }

    /** Called when the mode label / heading readout at the top is tapped. */
    void setOnHeaderTap(Runnable r) {
        onHeaderTap = r;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (onHeaderTap == null || e.getY() > headerBottom) {
            return false;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            performClick();
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        if (onHeaderTap != null) {
            playSoundEffect(android.view.SoundEffectConstants.CLICK);
            onHeaderTap.run();
        }
        return true;
    }

    void setNeedsCalibration(boolean needs) {
        needsCalibration = needs;
        invalidate();
    }

    void setMessage(String message) {
        this.message = message;
        invalidate();
    }

    static String cardinal(float deg) {
        return POINTS[Math.round(deg / 45f) % 8];
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(BG);
        float w = getWidth(), h = getHeight();
        if (message != null) {
            canvas.drawText(message, w / 2, h / 2, small);
            return;
        }

        // Heading readout at the top.
        float top = 8 * density;
        small.setColor(ACCENT);
        small.setTypeface(Typeface.DEFAULT_BOLD);
        canvas.drawText(mode, w / 2, top + 16 * density, small);
        small.setTypeface(Typeface.DEFAULT);
        small.setColor(Color.LTGRAY);
        String readout = hasHeading
                ? String.format(Locale.US, "%s%03d° %s", approximate ? "~" : "",
                        Math.round(heading) % 360, cardinal(heading))
                : "---";
        big.setColor(approximate ? Color.GRAY : Color.WHITE);
        canvas.drawText(readout, w / 2, top + 66 * density, big);

        float cx = w / 2;
        // Room left between the readout (with the marker) and the footer notes.
        float header = top + 104 * density, footer = 48 * density;
        headerBottom = top + 80 * density;
        float r = Math.max(40 * density, Math.min(w * 0.42f, (h - header - footer) / 2));
        float cy = header + r;

        // Fixed marker showing which way the phone points.
        fill.setColor(Color.WHITE);
        path.reset();
        path.moveTo(cx, cy - r - 4 * density);
        path.lineTo(cx - 10 * density, cy - r - 22 * density);
        path.lineTo(cx + 10 * density, cy - r - 22 * density);
        path.close();
        canvas.drawPath(path, fill);

        // The rotating card.
        canvas.save();
        canvas.rotate(-heading, cx, cy);
        line.setColor(Color.GRAY);
        line.setStrokeWidth(2 * density);
        canvas.drawCircle(cx, cy, r, line);
        for (int deg = 0; deg < 360; deg += 5) {
            float len = deg % 30 == 0 ? r * 0.12f : deg % 10 == 0 ? r * 0.07f : r * 0.04f;
            line.setColor(deg == 0 ? NORTH : deg % 30 == 0 ? Color.WHITE : Color.GRAY);
            line.setStrokeWidth((deg % 30 == 0 ? 3 : 1.5f) * density);
            canvas.drawLine(cx, cy - r, cx, cy - r + len, line);
            canvas.rotate(5, cx, cy);
        }
        // After a full turn the canvas is back at -heading.
        for (int i = 0; i < 8; i++) {
            boolean major = i % 2 == 0;
            label.setTextSize((major ? 26 : 16) * density);
            label.setColor(i == 0 ? NORTH : major ? Color.WHITE : Color.LTGRAY);
            canvas.drawText(POINTS[i], cx, cy - r * 0.70f + label.getTextSize() / 3, label);
            canvas.rotate(45, cx, cy);
        }
        // Degree numbers every 30°, skipping the cardinal points.
        label.setTextSize(12 * density);
        label.setColor(Color.GRAY);
        for (int deg = 0; deg < 360; deg += 30) {
            if (deg % 90 != 0) {
                canvas.drawText(String.valueOf(deg), cx, cy - r * 0.78f, label);
            }
            canvas.rotate(30, cx, cy);
        }
        // Needle: red end points north.
        float nw = r * 0.08f, nl = r * 0.5f;
        path.reset();
        path.moveTo(cx, cy - nl);
        path.lineTo(cx - nw, cy);
        path.lineTo(cx + nw, cy);
        path.close();
        fill.setColor(NORTH);
        canvas.drawPath(path, fill);
        path.reset();
        path.moveTo(cx, cy + nl);
        path.lineTo(cx - nw, cy);
        path.lineTo(cx + nw, cy);
        path.close();
        fill.setColor(Color.rgb(207, 216, 220));
        canvas.drawPath(path, fill);
        canvas.restore();
        fill.setColor(BG);
        canvas.drawCircle(cx, cy, nw * 0.5f, fill);

        // Footer notes.
        float y = h - 16 * density;
        if (needsCalibration) {
            small.setColor(WARN);
            canvas.drawText("Low accuracy: wave the phone in a figure 8", cx, y, small);
            small.setColor(Color.LTGRAY);
            y -= 24 * density;
        }
        if (note != null) {
            canvas.drawText(note, cx, y, small);
        }
    }
}
